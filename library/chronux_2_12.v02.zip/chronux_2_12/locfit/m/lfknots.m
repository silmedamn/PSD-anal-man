function z=lfknots(fit,varargin)
%
% very spartan version of the S lfknots function...
%
% Author: Catherine Loader.

z = fit.fit_points.fitted_values;

return;
